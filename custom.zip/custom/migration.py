import xmlrpc.client

url_db1 = "http://t-ajay-krishnan:8015"
db_1 = 'ladn'
username_db_1 = 'admin'
password_db_1 = 'admin'
common_1 = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url_db1))
models_1 = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url_db1))
version_db1 = common_1.version()
print(common_1)
print(models_1)
print(version_db1)

url_db2 = "http://localhost:8016"
db_2 = 'cool_db'
username_db_2 = '1'
password_db_2 = '1'
common_2 = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url_db2))
models_2 = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url_db2))
version_db2 = common_2.version()

uid_db1 = common_1.authenticate(db_1, username_db_1, password_db_1, {})
uid_db2 = common_2.authenticate(db_2, username_db_2, password_db_2, {})
print(uid_db2)

db_1_customers = models_1.execute_kw(db_1, uid_db1, password_db_1, 'res.partner', 'search_read', [[]],
                                     {'fields': ['id', 'name', 'email', 'country_id', 'mobile', 'image_1920',
                                                 'is_company', 'website', 'type', 'street',
                                                 'child_ids']})

db_2_customers = models_2.execute_kw(db_2, uid_db2, password_db_2, 'res.partner', 'search_read', [[]],
                                     {'fields': ['id', 'name', 'email', 'country_id', 'mobile', 'image_1920',
                                                 'is_company', 'website', 'type', 'street',
                                                 'child_ids']})
partners = []
for partner in db_2_customers:
    partners.append(partner['email'])
for customer in db_1_customers:
    if customer['email'] not in partners:
        data = {
            'name': customer['name'],
            'email': customer['email'],
            'country_id': customer['country_id'][0],
            'mobile': customer['mobile'],
            'image_1920': customer['image_1920'],
            'is_company': customer['is_company'],
            'website': customer['website'],
            'type': customer['type'],
            'street': customer['street'],
        }
        new_customers = models_2.execute_kw(db_2, uid_db2, password_db_2, 'res.partner', 'create', [data])
        child_data = []
        for child_id in db_1_customers['child_ids']:
            child_data.append([0, 0, {
                'name': child_id['name'],
                'email': child_id['email'],
            }])
        models_2.execute_kw(db_2, uid_db2, password_db_2, 'res.partner', 'write', [[new_customers], {'child_ids': child_data}])



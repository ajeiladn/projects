from odoo import fields, models


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    grade = fields.Selection(string="Grade", selection=[
            ('a', 'A'),
            ('b', 'B'),
            ('c', 'C'),
            ('d', 'D'),
        ],)

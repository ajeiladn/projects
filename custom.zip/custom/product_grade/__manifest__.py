{
    'name': 'Product Grade',
    'version': '16.0.1.0.0',
    'sequence': '-102',
    'summary': 'product_grade',

    'depends': [
        'point_of_sale',
    ],
    'data': [
        'views/product_template.xml',
    ],
    'assets': {
        'point_of_sale.assets': [
            'product_grade/static/src/js/receipt.js',
            'product_grade/static/src/xml/receipt.xml',
        ],
    },

    'installable': True,
    'application': True,
    'auto_install': False,
}
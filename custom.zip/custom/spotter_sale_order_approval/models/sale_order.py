from odoo import models, fields


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    is_approve = fields.Boolean(default=False)
    state = fields.Selection(selection_add=[('to_approve', 'To Approve'), ('to_verify', 'To verify'),
                                            ('refused', "Refused")])

    def action_to_approve(self):
        self.write({'state': 'to_approve'})
        self.is_approve = True

    def action_approve(self):
        self.write({'state': 'to_verify'})

    def action_verify(self):
        self.write({'state': 'sale'})

    def action_refuse(self):
        self.write({'state': 'refused'})

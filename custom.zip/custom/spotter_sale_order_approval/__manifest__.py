{
    'name': "Spotter SO Approval",
    'version': '16.0.1.0.0',
    'sequence': '-107',
    'summary': 'spotter_so_approval',

    'depends': [
        'sale_management',
    ],

    'data': [
        'views/sale_order.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}

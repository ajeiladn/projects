from . import hospital_management
from . import res_partner
from . import hospital_management_op
from . import hospital_management_consultation
from . import hospital_management_disease
from . import hr_employee
from . import hospital_management_medicine
from . import hospital_management_appointment

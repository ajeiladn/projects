from odoo import fields, models


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    avg_cost = fields.Float(string="Average Cost", compute='compute_avg_cost')

    def compute_avg_cost(self):
        for rec in self:
            rec.avg_cost = 0
            qty = 0
            price = 0
            counts = rec.env['purchase.order.line'].search([('product_id.product_tmpl_id.id', '=', rec.id),
                                                             ('order_id.state', '=', 'purchase')])
            for count in counts:
                qty += count.product_qty
                price += count.price_unit
            if qty > 0:
                rec.avg_cost = price/qty
            else:
                rec.avg_cost = 0

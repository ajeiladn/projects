{
    'name': 'Product Avg Cost',
    'version': '16.0.1.0.0',
    'sequence': '-108',
    'summary': 'product_avg_cost',
    'depends': [
        'product',
        'purchase',
    ],
    'data': [
        'views/product_template.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
{
    'name': 'Clear Cart',
    'version': '16.0.1.0.0',
    'sequence': '-101',
    'summary': 'clear_cart',

    'depends': [
        'website',
    ],
    'data': [
        'views/clear_cart_button.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'clear_cart/static/src/js/clear_cart_button.js',
        ]
    },

    'installable': True,
    'application': True,
    'auto_install': False,
}
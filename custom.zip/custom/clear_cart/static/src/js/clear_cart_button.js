odoo.define('clear_cart.button', function (require) {
"use strict";
var rpc = require('web.rpc');
    $(document).on('click', '#clear_cart_button_id', function(){
        rpc.query({
            route: '/shop/cart/clear',
            params: {},
        }).then(function () {
            window.location.reload();
        });
    });
});

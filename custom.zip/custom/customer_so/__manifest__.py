{
    'name': 'Customer SaleOrder',
    'version': '16.0.1.0.0',
    'sequence': '-109',
    'summary': 'customer_so',
    'depends': [
        'sale',
    ],
    'data': [
        'views/res_partner.xml',
        'views/product_template.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
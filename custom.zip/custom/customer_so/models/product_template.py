from odoo import fields, models, api


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    sale_count = fields.Integer(string="Total Sale Count", readonly=True, compute="compute_sale_count")

    def compute_sale_count(self):
        self.sale_count = 0
        count = self.env['sale.order.line'].search([('product_template_id', '=', self.id),
                                                    ('order_id.state', '!=', 'draft')])
        for i in count:
            self.sale_count += i.product_uom_qty

    @api.constrains('list_price')
    def constrains_list_price(self):
        products = self.env['sale.order.line'].search([('product_template_id', '=', self.id),
                                                       ('order_id.state', '=', 'draft')
                                                       ])
        for product in products:
            product.price_unit = self.list_price

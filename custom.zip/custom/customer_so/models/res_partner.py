from odoo import models, fields


class ResPartner(models.Model):
    _inherit = 'res.partner'

    sale_order_ids = fields.One2many('sale.order', 'partner_id')
    pdt_count = fields.Integer(compute='compute_pdt_count')
    # pdt_count = fields.Integer(string="Product Count")

    def compute_pdt_count(self):
        for rec in self:
            rec.pdt_count = 0
            counts = rec.env['sale.order.line'].search([('order_id.partner_id', '=', rec.id), ('order_id.state', '=', 'sale')])
            for count in counts:
                rec.pdt_count += count.product_uom_qty
            print(rec.pdt_count)

    def total_product_sold_tab(self):
        products = self.env['sale.order.line'].search([('order_id.partner_id', '=', self.id)]).mapped('product_template_id')
        return {
            'type': 'ir.actions.act_window',
            'name': 'Products Sold',
            'view_mode': 'tree,form',
            'res_model': 'product.template',
            'domain': [('id', 'in', products.ids)],
            'context': "{'create': False}"
        }

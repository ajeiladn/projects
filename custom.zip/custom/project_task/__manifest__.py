{
    'name': 'Project Task',
    'version': '16.0.1.0.0',
    'sequence': '-111',
    'summary': 'project_task',
    'depends': [
        'project'
    ],
    'data': [
        'views/project_task.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
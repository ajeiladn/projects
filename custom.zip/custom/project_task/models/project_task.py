from odoo import models, fields, api
from odoo.exceptions import ValidationError


class ProjectTask(models.Model):
    _inherit = 'project.task'

    order = fields.Char(string="Order")

    # order = fields.Integer(string="Order", compute='compute_order', readonly=True)

    # def compute_order(self):
    #     self.order = 0
    #     if self.project_id.task_count != 0:
    #         self.order = self.project_id.task_count
    #     else:
    #         self.order = 1

            # print("12345")
            # print('proj = ', self.project_id.name)
            # print('stage = ', self.stage_id.name)
            # print("stage...", self.date_last_stage_update)
            # print("count>>>", self.project_id.task_count)
            #
            # pj = self.env['project.project'].search([])
            #
            # "task_ids" onetomany task->project

    @api.onchange('stage_id')
    def onchange_stage_id(self):
        print(self.name)
        if self.stage_id.name == 'Done':
            print("qwerty")
            # print("date_last_stage_update ", self.date_last_stage_update)
            # self.search([('order', '=', self.order+1)])

    # @api.model
    # def create(self):
    #     print("qwerty")
    #
    #     return super(ProjectTask, self)

    # if 'order' not in vals:
    #     vals['order'] = self.env['ir.sequence'].next_by_code('project.task') or '/'
    # return super(ProjectTask, self).create(vals)

    @api.constrains('order')
    def check_duplicate(self):
        for rec in self:
            srl_no = self.env['project.task'].search(
                [('sequence_order', '=', rec.sequence_order), ('id', '!=', rec.id)])
            if srl_no:
                raise ValidationError("serial number already exists")


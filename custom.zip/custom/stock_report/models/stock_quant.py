from odoo import models
import base64


class StockQuant(models.Model):
    _inherit = 'stock.quant'

    def action_sent_mail(self):

        datas = self.env['stock.quant'].search([])
        stocks = {'stock': datas}
        admins = []
        group = self.env.ref('stock.group_stock_manager').users
        for user in group:
            admins.append(user.email)

        report_template_id = self.env.ref('stock_report.stock_report_pdf')._render_qweb_pdf('stock_report.stock_report_pdf', self.id, data=stocks)
        data_binary = base64.b64encode(report_template_id[0])
        ir_values = {
            'name': "Stock Report",
            'type': 'binary',
            'datas': data_binary,
            'store_fname': data_binary,
            'mimetype': 'application/x-pdf',
        }
        data_id = self.env['ir.attachment'].create(ir_values)
        template = self.env.ref('stock_report.stock_report_email_template')
        template.attachment_ids = [(6, 0, [data_id.id])]
        if len(admins) > 0:
            email_values = {'email_to': admins[0],
                            'email_cc': ", ".join(admins[1:]),                      # admins[1]
                            'subject': 'Stock Report'}
            template.send_mail(self.id, email_values=email_values, force_send=True)
            template.attachment_ids = [(3, data_id.id)]
            return True
        return False


{
    'name': 'Stock Report',
    'version': '16.0.1.0.0',
    'sequence': '-106',
    'summary': 'stock_report',

    'depends': [
        'base',
        'mail',
        'stock',
    ],
    'data': [
        'data/mail_scheduler.xml',
        'data/mail_template.xml',
        'report/ir_actions_report.xml',
        'report/stock_report_template.xml',
    ],

    'installable': True,
    'application': True,
    'auto_install': False,
}
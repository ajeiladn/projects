from odoo import fields, models


class Estate(models.Model):
    _name = "estate.estate"
    _description = "estate estate"

    name = fields.Char(required=True)
    description = fields.Text(default='')
    date = fields.Date()
    price = fields.Integer(required=True)
    garden = fields.Boolean(default=False)
    # garden_orientation = fields.Selection() ####selection error

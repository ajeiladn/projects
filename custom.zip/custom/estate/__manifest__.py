{
    'name': 'REAL ESTATE',
    'version': '16.0.1.0.0',
    'sequence': '-21',
    'summary': 'real estate agents and dealings..',

    'depends': [

    ],

    'data': [
        'security/ir.model.access.csv',
        'views/estate.xml',
    ],

    'demo': [],
    'css': [],

    'installable': True,
    'application': True,
    'auto_install': False,
}

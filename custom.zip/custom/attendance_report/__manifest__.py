{
    'name': 'Attendance Report',
    'version': '16.0.1.0.0',
    'sequence': '-110',
    'summary': 'attendance_report',
    'depends': [
        'hr_attendance',
    ],
    'data': [
        'data/mail_scheduler.xml',
        'data/mail_template.xml',
        'report/ir_actions_report.xml',
        'report/attendance_report_template.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
from odoo import models
import base64
from datetime import datetime


class HrAttendance(models.Model):
    _inherit = 'hr.attendance'

    def action_attendance_report(self):
        today = datetime.today()
        date_start = today.strftime('%Y-%m-%d 00:00:00')
        date_end = today.strftime('%Y-%m-%d 23:59:59')
        attendance = self.env['hr.attendance'].search([('check_in', '>=', date_start),
                                                       ('check_out', '<=', date_end)
                                                       ])
        attendance_dict = {'attendances': attendance}
        from_email = self.env.user.company_id.email
        admins = []
        group = self.env.ref('hr_attendance.group_hr_attendance_user').users
        for user in group:
            admins.append(user.email)

        report_template_id = self.env.ref('attendance_report.attendance_report_pdf')._render_qweb_pdf(
            'attendance_report.attendance_report_pdf', self.id, data=attendance_dict)
        data_binary = base64.b64encode(report_template_id[0])
        ir_values = {
            'name': "Attendance Report",
            'type': 'binary',
            'datas': data_binary,
            'store_fname': data_binary,
            'mimetype': 'application/x-pdf',
        }
        data_id = self.env['ir.attachment'].create(ir_values)
        template = self.env.ref('attendance_report.attendance_report_email_template')
        template.attachment_ids = [(6, 0, [data_id.id])]
        if len(admins) > 0:
            email_values = {'email_from': from_email,
                            'email_to': admins[0],
                            'email_cc': ", ".join(admins[1:]),
                            'subject': 'Attendance Report'}
            template.send_mail(self.id, email_values=email_values, force_send=True)
            template.attachment_ids = [(3, data_id.id)]
            return True
        return False

{
    'name': 'Purchase Limit',
    'version': '16.0.1.0.0',
    'sequence': '-103',
    'summary': 'purchase_limit',

    'depends': [
        'point_of_sale',
    ],
    'data': [
        'views/res_partner.xml',
    ],
    'assets': {
        'point_of_sale.assets': [
            'purchase_limit/static/src/js/pos_popup.js',
            'purchase_limit/static/src/xml/limit.xml',
        ],
    },

    'installable': True,
    'application': True,
    'auto_install': False,
}
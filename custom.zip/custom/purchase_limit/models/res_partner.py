from odoo import fields, models


class ResPartner(models.Model):
    _inherit = 'res.partner'

    is_limit = fields.Boolean(string="Purchase Limit", default=False)
    company_id = fields.Many2one('res.company', store=True, string="Company",
                                 default=lambda self: self.env.user.company_id.id)
    currency_id = fields.Many2one('res.currency', string="Currency",
                                  related='company_id.currency_id',
                                  default=lambda self: self.env.user.company_id.currency_id.id, readonly=True)
    limit = fields.Monetary(string="Limit", store=True)

from . import res_partner
from . import pos_session

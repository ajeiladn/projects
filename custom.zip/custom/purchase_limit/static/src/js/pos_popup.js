odoo.define('purchase_limit.popup', function(require){
    "use_strict";

    const PaymentScreen = require('point_of_sale.PaymentScreen');
    const Registries = require('point_of_sale.Registries');

    const ValidateOverride = PaymentScreen =>
        class extends PaymentScreen {
            async validateOrder(isForceValidate) {
                if(this.currentOrder.partner){
                    var limit = this.currentOrder.partner.limit
                    var total = this.currentOrder.get_total_with_tax()
                    if(total > limit){
                        this.showPopup('ConfirmPopup', {
                            title: ('PURCHASE LIMIT EXCEEDS !!'),
                            body: ('PURCHASE LIMIT=' + limit),
                        });
                        return false;
                    }
                }
                else{
                    const { confirmed } = await this.showPopup('ConfirmPopup', {
                    title: ('PLEASE SELECT A CUSTOMER !!'),
                    });
                    if (confirmed) {
                        this.selectPartner();
                    }
                    return false;
                }
                await super.validateOrder(isForceValidate);
            }
        };
    Registries.Component.extend(PaymentScreen, ValidateOverride);
    return PaymentScreen;
});

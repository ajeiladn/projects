from odoo import fields, models, api


class InvRepair(models.Model):
    _name = 'inv.repair'
    _inherit = 'mail.thread', 'mail.activity.mixin'
    _description = 'inventory repair'

    sale_order_id = fields.Many2one('sale.order', string="Sale Order", domain=[('state', '=', 'sale')], required=True)
    partner_id = fields.Many2one(related='sale_order_id.partner_id', string="Customer Name")
    products_id = fields.Many2one('product.product')
    state = fields.Selection(selection=[('draft', 'Draft'), ('confirm', 'Confirm'), ('done', 'Done')],
                             string='State', default='draft')

    @api.onchange('sale_order_id')
    def onchange_sale_order_id(self):
        self.products_id = False
        product_id = self.sale_order_id.order_line.mapped('product_id')
        return {'domain': {'products_id': [('id', 'in', product_id.ids)]}}

    def action_confirm(self):
        self.write({'state': "confirm"})
        so = self.env['sale.order'].browse(self.sale_order_id.id)
        so.is_repair = True

    def action_done(self):
        self.write({'state': "done"})

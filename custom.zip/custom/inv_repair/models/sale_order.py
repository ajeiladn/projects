from odoo import models, fields, api, _


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    is_repair = fields.Boolean(string='Repair', default=False, readonly=True)

    @api.onchange('partner_id')
    def onchange_partner_id(self):
        res = {}
        pending_repair = self.env['inv.repair'].search(
            [('partner_id', '=', self.partner_id.id), ('state', '!=', 'done')])
        if pending_repair:
            res = {'warning': {
                'title': _('Warning'),
                'message': _('This user has some pending repair requests.')
            }}
            if res:
                return res

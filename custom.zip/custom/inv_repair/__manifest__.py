{
    'name': 'INV REPAIR',
    'version': '16.0.1.0.0',
    'sequence': '-105',
    'summary': 'inv_repair',

    'depends': [
        'sale',
    ],

    'data': [
        'security/ir.model.access.csv',
        'views/inv_repair.xml',
        'views/sale_order.xml',

    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'assets': {
    }
}
